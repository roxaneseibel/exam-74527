﻿using System.Security.Cryptography.X509Certificates;

namespace question_4_74527
{
    public class CarRegistration
    {
        public string number {
            get
            {
                return this.number;
            }
            set
            {
                validateNumber(value);
            }
        }
        /*public int year {
            get
            {
                return (int)this.year;
            }
            set
            {
                if(value%100 ==0)
                {
                    this.year = value;
                }
                else
                {
                    throw new ArgumentException("Not the good lenght");
                }
            }
        }
        public string county
        {
            get
            {
                return this.county;
            }
            set
            {
                if(value.Length == 2 || value.Length ==1) 
                {
                    this.county = value;
                }
            }
        }
        public int digit {
            get
            {
                return this.digit;
            }
            set
            {
                if (value%100000 <= 0)
                {
                    this.digit = value;
                }
            }
        }*/

        public void validateNumber(string n)
        {
            string res = "";
            int j = 1;
            for(int i = 0; i < n.Length; i++)
            {
                string p = "";
                while (n[i] != '-')
                {
                    p+= n[i];
                    i++;
                }

                //first part of the plate, the year
                if(j==1)
                {
                    //see the lenght
                    if (p.Length != 3)
                    {
                        this.number = "N/A";
                        i = 10000;
                    }
                    else
                    {
                        //see if it is all digit
                        foreach (var item in p)
                        {
                            if(isNotGigit(item) == true)
                            {
                                this.number = "N/A";
                                i = 10000;
                            }
                        }
                    }
                }
                //second part of the plate, the country
                else if(j==2)
                {
                    if (p.Length != 2)
                    {
                        this.number = "N/A";
                        i = 10000;
                    }
                    else
                    {
                        //see if the country exist
                        if(p != "D" && p!="L" && p!="RN" && p!="SO")
                        {
                            this.number = "N/A";
                            i = 10000;
                        }
                    }
                }
                else
                {
                    if (p.Length >6)
                    {
                        this.number = "N/A";
                        i = 10000;
                    }
                    else
                    {
                        //see if it is all digit
                        foreach (var item in p)
                        {
                            if (isNotGigit(item) == true)
                            {
                                this.number = "N/A";
                                i = 10000;
                            }
                        }
                    }
                }
                j++;
                res += p;
                

            }
            this.number = res;
        }


        public static bool isNotGigit(char n)
        {
            bool res = false;
            switch (n)
            {
                case '0':
                    res = false;
                    break;
                case '1':
                    res = false;
                    break;
                case '2':
                    res = false;
                    break;
                case '3':
                    res = false;
                    break;
                case '4':
                    res = false;
                    break;
                case '5':
                    res = false;
                    break;
                case '6':
                    res = false;
                    break;
                case '7':
                    res = false;
                    break;
                case '8':
                    res = false;
                    break;
                case '9':
                    res = false;
                    break;
                default:
                    res = true;
                    break;


            }
            return res;
        }
    }

    
}