﻿using question_3_74527;
using System;
using System.Runtime.CompilerServices;
namespace question_3_74527
{



    public static class Movie
    {

        public static string Name { get; set; }
        public static string Rating { get; set; }
        public static int Running_time { get; set; }
        public static string Director { get; set; }


        public static void movie(string name, string rating, int running, string director)
        {
            Name = name;
            Rating = rating;
            Running_time = running;
            Director = director;
        }

        public static string name()
        {
            return Name;
        }

        public static string director()
        {
            return Director;
        }

        public static string rating()
        {
            return Rating;
        }

        public static int runningTime()
        {
            return Running_time;
        }


        public static void setRating(string rating)
        {
            if (rating == "G" || rating == "PG" || rating == "PG-13" ||
                rating == "R" || rating == "NC_17")
            {
                Rating = rating;
            }
            else
            {
                Rating = "NC_17";
            }
        }

        public static void setRunningTime(int running)
        {
            Running_time = running;
        }

        public static void toString()
        {
            Console.WriteLine("name: " + Name + ", rating: " + Rating + ", running time: " + Running_time + ", director: " + Director);
        }



        
    }


    /*public static class Create
    {
        Movie movie1 = new Movie();
        Movie movie2 = new Movie();
        Movie movie3 = new Movie();
    }*/




}
