﻿//a- A sealed class can't be herited.

//b-
using System;
namespace question_1_74527
{
    public sealed class BuildingCodes
    {
        public int BuildingId { get; set; }
        public string BuildingLocation
        {
            get
            {
                return BuildingLocation;
            }
            set
            {
                if (value.Length <= 3 || value.Length >= 7)
                {
                    throw new ArgumentOutOfRangeException("Not the good lenght.");
                }
                else
                {
                    BuildingLocation = value;
                }
            }
        }
        public string BuildingCode
        {
            get
            {
                return BuildingCode;
            }
            set
            {
                if (value.Length >= 21)
                {
                    throw new ArgumentOutOfRangeException("Lenght less than 20 is required.");
                }
                else
                {
                    BuildingCode = value;
                }
            }
        }


    }


    

    
}